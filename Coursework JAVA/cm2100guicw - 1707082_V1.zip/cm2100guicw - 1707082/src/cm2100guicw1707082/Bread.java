package cm2100guicw1707082;

/**
 * enumerated type used in CM2100 GUI Coding Coursework
 * @author david
 */
public enum Bread {
    WHITE, WHOLEMEAL, BAGEL, RYE, PITA
}
